package br.upf.usuarios_produtos

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SistemaDeEventosApplicationTests {

	@Test
	fun contextLoads() {
	}

}
