package br.upf.usuarios_produtos.dtos

data class LoginResponseDTO(val login: String)