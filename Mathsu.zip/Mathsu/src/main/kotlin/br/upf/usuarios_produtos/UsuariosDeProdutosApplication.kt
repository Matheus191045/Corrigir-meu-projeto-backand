package br.upf.usuarios_produtos

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class UsuariosDeProdutosApplication

fun main(args: Array<String>) {
	runApplication<UsuariosDeProdutosApplication>(*args)
}
