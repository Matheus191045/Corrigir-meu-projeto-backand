package br.upf.usuarios_produtos.converters

import br.upf.usuarios_produtos.model.Produto
import br.upf.usuarios_produtos.dtos.ProdutoDTO
import br.upf.usuarios_produtos.dtos.ProdutoResponseDTO
import br.upf.usuarios_produtos.model.StatusProduto
import jakarta.validation.constraints.NotBlank
import jakarta.validation.constraints.NotNull

import org.springframework.stereotype.Component

@Component
class ProdutoConverter {

    fun toProduto(dto: ProdutoDTO): Produto {
        return Produto(
            nome = dto.nome,
            preco = dto.preco,
            qtdEstoque = dto.qtdEstoque,
            descricao = dto.descricao,
            status = dto.status,
            pedindo = listOf()

        )
    }


    fun toProdutoResponseDTO(produto: Produto): ProdutoResponseDTO {
        return ProdutoResponseDTO(
            id = produto.id,
            nome = produto.nome,
            preco = produto.preco,
            qtdEstoque = produto.qtdEstoque,
            descricao = produto.descricao,
            status = produto.status,
            pedindo = produto.pedindo
        )
    }


}