package br.upf.usuarios_produtos.model

import jakarta.persistence.Entity
import jakarta.persistence.EnumType
import jakarta.persistence.Enumerated
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id
import jakarta.persistence.OneToMany
import java.time.LocalDate
import java.time.LocalDateTime

@Entity
data class Produto(
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id: Long? = null,
    val nome: String,
    val preco: Int,  // ou Decimal
    val qtdEstoque: Int,
    val descricao: String,
    @Enumerated(value = EnumType.STRING)
    val status: StatusProduto,
    @OneToMany(mappedBy = "produto")
    val pedindo: List<Pedindos> = listOf()

)


