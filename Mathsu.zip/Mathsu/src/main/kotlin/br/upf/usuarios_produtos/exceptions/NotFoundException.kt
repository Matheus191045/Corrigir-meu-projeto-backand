package br.upf.usuarios_produtos.exceptions

import java.lang.RuntimeException

class NotFoundException(override val message: String)
    : RuntimeException()